#!/usr/bin/env bash

cd test
# cd python
python3 -m python.input.run_input_tests
cd ..
