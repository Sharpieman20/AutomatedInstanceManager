



def test_inputs_1():
    from ..build_test_env import run_test
    run_test()
    pass
    