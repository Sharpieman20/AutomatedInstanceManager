

def test_inputs_1():
    from ..build_test_env import start_test
    start_test()
    pass
