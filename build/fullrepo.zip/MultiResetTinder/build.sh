
zip -r release src/**
rm -rf build
mkdir build
mv release.zip build
