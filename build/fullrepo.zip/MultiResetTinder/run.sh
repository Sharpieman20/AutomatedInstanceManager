# TODO - delete this file

python3 src/python/main.py settings.json