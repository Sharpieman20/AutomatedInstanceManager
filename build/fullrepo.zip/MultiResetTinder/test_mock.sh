# TODO - delete this file

rm -rf ~/.aimlog
mkdir ~/.aimlog
java test/LaunchMockMC.java 1
