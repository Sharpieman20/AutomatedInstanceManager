public class RamBuffer {

    public static void main(String[] args) throws Exception {

        Thread.sleep(Integer.parseInt(args[0]));
        System.exit(0);
    }
}