#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Python library to communicate with an obs-websocket server.
"""

from .core import obsws  # noqa: F401
